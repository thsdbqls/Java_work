package d260122_02;

import java.io.IOException;

public class PhonebookMain {

	public static void main(String[] args) throws IOException {
		new PhonebookProgram();

	}

}
