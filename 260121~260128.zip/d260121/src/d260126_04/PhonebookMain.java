package d260126_04;

public class PhonebookMain {

	public static void main(String[] args) {
		new PhonebookFrame();
	}

}
