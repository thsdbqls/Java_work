package d260126_03;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FrameMain2 {

	public static void main(String[] args) {
//		Frame f = new Frame();
//		f.setBounds(0, 0, 500, 200);  //x좌표, y좌표, weidth, height
//		f.setVisible(true);
//		f.setTitle("전화번호 부");
		
		//new PhonebookFrame2();
		new PhonebookFrame();
	}

}

