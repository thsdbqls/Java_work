package d260126_01;

import java.io.IOException;

public class PhonebookMain {

	public static void main(String[] args) throws IOException {
		new PhonebookProgram();

	}

}
