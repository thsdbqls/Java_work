package d260127;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PhonebookFrame extends Frame{
	private PhonebookManager pm = new PhonebookManager();
	
	// 메인메뉴 부폼
	Button menuInsertbtn;
	Button menuAllprintbtn;
	Button menuViewbtn;
	Button menuUpdatebtn;
	Button menuDeletebtn;
	
	//입력 부품
	Label insertNamelb;
	Label insertHplb;
	Label insertEmaillb;
	
	TextField insertNametf;
	TextField insertHptf;
	TextField insertEmailtf;
	
	Button insertInsertbtn = new Button("전화번호부 추가 입력");
	
	//전체 출력 부품
	java.awt.List listBox;
	Label viewIdlb, viewNamelb, viewHplb, viewEmaillb;
	
	//찾기 부품 생성
	Label updateNamelb ,searchIdlb, searchNamelb, searchHplb, searchEmaillb;
	TextField updateNametf;
	Button updatebtn;
	java.awt.List updateSearchListBox;
	
	//수정 부품
	/*Label UpdateIdlb, UpdateNamelb, UpdateHplb, UpdateEmaillb;
	TextField UpdateIdtf,UpdateNametf, UpdateHptf, UpdateEmailtf;
	Button Updatebtn, cancelbtn;
	java.awt.List UpdateSearchListBox;*/
	
	//삭제 부품
	
	
	
	public PhonebookFrame() {   // 생성자
		setTitle("전화번호부 프로그램");
		setBounds(0,0,400,700);
		setLayout(new FlowLayout());
		setVisible(true);
		
		// 윈도우 닫기 이밴트
		addWindowListener(new WindowAdapter() {
		@Override
		public void windowClosing(WindowEvent e) {
			System.exit(0);
		}
		});
		
		// 메인 메뉴 부품 만들기
		menuInsertbtn = new Button("전화번호부 입력");
		menuAllprintbtn = new Button("전화번호부 출력");
		menuViewbtn = new Button("전화번호부 찾기");
		menuUpdatebtn = new Button("전화번호부 수정");
		menuDeletebtn = new Button("전화번호부 삭제");
		
		// 버튼 크기 변경
		menuInsertbtn.setPreferredSize(new Dimension(300,50));
		menuAllprintbtn.setPreferredSize(new Dimension(300,50));
		menuViewbtn.setPreferredSize(new Dimension(300,50));
		menuUpdatebtn.setPreferredSize(new Dimension(300,50));
		menuDeletebtn.setPreferredSize(new Dimension(300,50));
		
		//부품 추가하기(화면에 추가(표시))
		add(menuInsertbtn);
		add(menuAllprintbtn);
		add(menuViewbtn);
		add(menuUpdatebtn);
		add(menuDeletebtn);
		
		//insert기능에 부품을 만들고 add
		insertNamelb = new Label("이름 :");
		insertHplb = new Label("전화번호 :");
		insertEmaillb = new Label("이메일 :");
		
		insertNametf = new TextField();
		insertHptf = new TextField();
		insertEmailtf = new TextField();
		
		insertInsertbtn = new Button("전화번호부 추가 입력");
		
		insertNamelb.setVisible(false);
		insertHplb.setVisible(false);
		insertEmaillb.setVisible(false);
		insertNametf.setVisible(false);
		insertHptf.setVisible(false);
		insertEmailtf.setVisible(false);
		insertInsertbtn.setVisible(false);
		
		add(insertNamelb);
		add(insertNametf);
		add(insertHplb);
		add(insertHptf);
		add(insertEmaillb);
		add(insertEmailtf);
		add(insertInsertbtn);
		
		insertNamelb.setAlignment(Label.RIGHT);
		// 이름 레이블 크기 변경
		insertNamelb.setPreferredSize(new Dimension(100,50));
		// 이름 입력 상자 크기 변경
		insertNametf.setColumns(30);
		
		// 전화번호, 이메일 크기 변경
		insertHplb.setPreferredSize(new Dimension(100,50));
		insertHptf.setColumns(30);
		insertEmaillb.setPreferredSize(new Dimension(100,50));
		insertEmailtf.setColumns(30);
		
		insertInsertbtn.setPreferredSize(new Dimension(300, 50));
		

		
		
		// 추가한 부품을 처리하기 위한 버튼 이밴트 추가
		menuInsertbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				insertNamelb.setVisible(true);
				insertHplb.setVisible(true);
				insertEmaillb.setVisible(true);
				insertNametf.setVisible(true);
				insertHptf.setVisible(true);
				insertEmailtf.setVisible(true);
				insertInsertbtn.setVisible(true);

				// 화면을 새로 그리기 위해서는 2개의 함수가 동시 호출
				revalidate();
				repaint();  // 화면을 재 시작
				
				//insertbtn을 눌렀을 때 이벤트 처리
				insertInsertbtn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						System.out.println(insertNametf.getText());
						System.out.println(insertHptf.getText());
						System.out.println(insertEmailtf.getText());
						
						pm.insert(insertNametf.getText(),
								insertHptf.getText(),
								insertEmailtf.getText());
						
						System.out.println(pm.getList());
						
						insertNametf.setText("");
						insertHptf.setText("");
						insertEmailtf.setText("");
						
						insertNametf.setFocusable(true);
					}
				});
			}
		});
		
		// 전체 출력 기능을 메인 메뉴에 만들고 add
		// 전체 출력 부품 생성 및 설정
		listBox = new List(10);
		
		// 리스트 박스 크기 변경
		listBox.setPreferredSize(new Dimension(500,0));
		Panel panel = new Panel();
		panel.setLayout(new BorderLayout());
		panel.setSize(500,0);
		panel.add(listBox);
		add(panel);
		// 그러나 변경되지 않는다
		// 방법을 찾아봐야 함
		
		//add(listBox);
		listBox.setVisible(false);
		
		//전체 리스트 보기
		menuAllprintbtn.addActionListener
		(new ButtonFuc(this,pm.getList()));
		
		// 전체 리스트 안에서 레이블 설정
		viewIdlb=new Label("아이디"); viewIdlb.setBackground(Color.ORANGE);
		viewNamelb=new Label("이름"); viewNamelb.setBackground(Color.green);
		viewHplb=new Label("전화번호"); viewHplb.setBackground(Color.YELLOW);
		viewEmaillb=new Label("이메일"); viewEmaillb.setBackground(Color.LIGHT_GRAY);

		
		//레이블 크기 정하기
		viewIdlb.setPreferredSize(new Dimension(200,30));
		viewNamelb.setPreferredSize(new Dimension(200,30));
		viewHplb.setPreferredSize(new Dimension(200,30));
		viewEmaillb.setPreferredSize(new Dimension(200,30));
		
		add(viewIdlb);
		add(viewNamelb);
		add(viewHplb);
		add(viewEmaillb);
		
		viewIdlb.setVisible(false);
		viewNamelb.setVisible(false);
		viewHplb.setVisible(false);
		viewEmaillb.setVisible(false);
		
		//전체 리스트에서 하나의 아이템을 선택했을 때 상세보기
		// 1) 리스트를 클릭할 때
		// 2) 리스트의 정보를 가지고 온 후 분리
		// 3)분리된 데이터를 레이블에 표시(레이블을 생성/설정/추가
		listBox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				setVisible();
				
				listBox.setVisible(true);
				viewIdlb.setVisible(true);
				viewNamelb.setVisible(true);
				viewHplb.setVisible(true);
				viewEmaillb.setVisible(true);
				
				// 아래의 데이터는 프레임에서 LIstBox 내용이므로 Email 확인 불가
				// String[] datas = listBox.getSelectedItem().split(" ");
				/*
				String data=listBox.getItem((int) e.getItem());
				String[] datas = data.split(" ");
				System.out.println(datas);*/
				
				// listBox에서 id를 구하고
				// 전체 리스트 정보에서 id와 비교하여 같은 아이디를 출력하시오
				//Phonebook p=pm.getList().get((int) e.getItem());
				
				String[] datas = listBox.getSelectedItem().split(" ");
				//System.out.println(datas[0]);
				
				int index = listBox.getSelectedIndex();
				//System.out.println(index);
				
//				String item = listBox.getSelectedItem();
//				int selectedId = Integer.parseInt(item.split(" ")[0]);
				
				int id = Integer.parseInt(listBox.getSelectedItem().split(" ")[0]);

				for (Phonebook p : pm.getList()) {
				    if (p.getId() == id && listBox.getSelectedIndex()!=0) {
			
				
				    		viewIdlb.setText("아이디 : " + p.getId());
				    		viewNamelb.setText("이름 : " + p.getName());
				    		viewHplb.setText("전화변허 : " + p.getHp());
				    		viewEmaillb.setText("이메일 : " + p.getEmail());
				
				
				    		revalidate();
				    		repaint();
				    }
				}
			}
		});
		
		// 찾기 부품 설정
		updateNamelb = new Label("찾을 이름은 : ");
		updateNametf = new TextField();
		updatebtn = new Button("찾기");
				
		updateNamelb.setVisible(false);
		updateNametf.setVisible(false);
		updatebtn.setVisible(false);
		
		updateSearchListBox = new List();
		updateSearchListBox.setVisible(false);
		
		searchIdlb = new Label("아이디 : ");
		searchNamelb = new Label("이름 : ");
		searchHplb = new Label("전화번호 : ");
		searchEmaillb = new Label("이메일 : ");
		
		//레이블 크기 정하기
		searchIdlb.setPreferredSize(new Dimension(100,30));
		searchNamelb.setPreferredSize(new Dimension(100,30));
		searchHplb.setPreferredSize(new Dimension(100,30));
		searchEmaillb.setPreferredSize(new Dimension(100,30));
		
		searchIdlb.setVisible(false);
		searchNamelb.setVisible(false);
		searchHplb.setVisible(false);
		searchEmaillb.setVisible(false);
		
				
		add(updateNamelb);
		add(updateNametf);
		add(updatebtn);
		
		add(updateSearchListBox);
		
		add(searchIdlb);
		add(searchNamelb);
		add(searchHplb);
		add(searchEmaillb);
				
//		updateNamelb.setAlignment(Label.RIGHT);  // 오른쪽 정렬
//		updateNamelb.setSize(new Dimension(200,0));  // 레이블상자 크기
		updateNametf.setColumns(30);// 입력상자 크기
		
		// 전화번호부 찾기 버튼 클릭했을 때 이벤트 등록
		menuViewbtn.addActionListener(new ActionListener() {
			// 동작에 대한 리스너를 menuViewbtn에 추가한다
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				updateNamelb.setVisible(true);
				updateNametf.setVisible(true);
				updatebtn.setVisible(true);
				
				
				revalidate(); repaint();
				
			}
		});
		
		// 찾기 버튼 실행
		updatebtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				updateNamelb.setVisible(true);
				updateNametf.setVisible(true);
				updatebtn.setVisible(true);
				
				updateSearchListBox.setVisible(true);
				
				String search = updateNametf.getText();
				Phonebook p=pm.selectByName(search);  // 어떤 한 명을 리턴해 줘야 한다
				
				if(p!=null) {
					updateSearchListBox.add(p.getId() + " " + p.getName());
				}
				revalidate(); repaint();
			}
		});
		
		// 검색한 리스트 박스를 클릭할 때
		updateSearchListBox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				// 상세보기를 재활용
				updateNamelb.setVisible(true);
				updateNametf.setVisible(true);
				updatebtn.setVisible(true);
				
				updateSearchListBox.setVisible(true);
				
				viewIdlb.setVisible(true);
				viewNamelb.setVisible(true);
				viewHplb.setVisible(true);
				viewEmaillb.setVisible(true);
				
				int id = Integer.parseInt(updateSearchListBox.getSelectedItem().split(" ")[0]);
				
				for (Phonebook p : pm.getList()) {
				    if (p.getId() == id && listBox.getSelectedIndex()!=0) {
				    	viewIdlb.setText("아이디 : " + p.getId());
				    	viewNamelb.setText("이름 : " + p.getName());
				    	viewHplb.setText("전화변허 : " + p.getHp());
				    	viewEmaillb.setText("이메일 : " + p.getEmail());
				    }
				}
				revalidate();
	    		repaint();
				
			}
		});
		
		
		// 수정 부품 설정
/*		UpdateIdlb = new Label("  아이디 : ");
		UpdateIdtf = new TextField();
		
		UpdateNamelb = new Label("  이름 : ");
		UpdateNametf = new TextField();
		
		UpdateHplb = new Label("  전화 : ");
		UpdateHptf = new TextField();
		
		UpdateEmaillb = new Label("  Email : ");
		UpdateEmailtf = new TextField();
		
				
		Updatebtn = new Button("수정");
		cancelbtn = new Button("취소");
		
		UpdateSearchListBox = new List();
		
		UpdateIdlb.setVisible(false);
		UpdateNamelb.setVisible(false);
		UpdateHplb.setVisible(false);
		UpdateEmaillb.setVisible(false);
		
		UpdateIdtf.setVisible(false);
		UpdateNametf.setVisible(false);
		UpdateHptf.setVisible(false);
		UpdateEmailtf.setVisible(false);
		
		Updatebtn.setVisible(false);
		cancelbtn.setVisible(false);
		
		UpdateSearchListBox.setVisible(false);
		
		add(UpdateSearchListBox);
		add(UpdateIdlb);
		add(UpdateIdtf);
		add(UpdateNamelb);
		add(UpdateNametf);
		add(UpdateHplb);
		add(UpdateHptf);
		add(UpdateEmaillb);
		add(UpdateEmailtf);
		add(Updatebtn);
		add(cancelbtn);
		
		
		UpdateIdtf.setColumns(30);
		UpdateNametf.setColumns(30);
		UpdateHptf.setColumns(30);
		UpdateEmailtf.setColumns(30);
		
		//UpdateIdlb.setSize(new Dimension(50,50));
		//Updatebtn.setSize(new Dimension(50,0));
		
		menuUpdatebtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				updateNamelb.setVisible(true);
				updateNametf.setVisible(true);
				updatebtn.setVisible(true);
				
				
				
				revalidate(); repaint();
			}
		});
		
		updatebtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				updateNamelb.setVisible(true);
				updateNametf.setVisible(true);
				updatebtn.setVisible(true);
				
				UpdateSearchListBox.setVisible(true);
				updateSearchListBox.setVisible(false);
				
				String search = updateNametf.getText();
				Phonebook p=pm.selectByName(search);  // 어떤 한 명을 리턴해 줘야 한다
				
				if(p!=null) {
					UpdateSearchListBox.add(p.getId() + " " + p.getName());
				}
				revalidate(); repaint();
				
			}
		});
		
		UpdateSearchListBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				updateNamelb.setVisible(true);
				updateNametf.setVisible(true);
				updatebtn.setVisible(true);
				
				UpdateSearchListBox.setVisible(true);
				
				UpdateIdlb.setVisible(true);
				UpdateNamelb.setVisible(true);
				UpdateHplb.setVisible(true);
				UpdateEmaillb.setVisible(true);
				
				UpdateIdtf.setVisible(true);
				UpdateNametf.setVisible(true);
				UpdateHptf.setVisible(true);
				UpdateEmailtf.setVisible(true);
				
				Updatebtn.setVisible(true);
				cancelbtn.setVisible(true);

				
				revalidate(); repaint();
				
			}
		});
		
		Updatebtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible();
				
				revalidate(); repaint();
			}
		});
		*/
		
	}

	public java.awt.List getListBox() {
		return listBox;
	}

	public void setListBox(java.awt.List listBox) {
		this.listBox = listBox;
	}
	
	
	
	
	public void setVisible() {
		// 입력
		insertNamelb.setVisible(false);
		insertHplb.setVisible(false);
		insertEmaillb.setVisible(false);
		insertNametf.setVisible(false);
		insertHptf.setVisible(false);
		insertEmailtf.setVisible(false);
		insertInsertbtn.setVisible(false);
		
		// 전체 출력
		listBox.setVisible(false);
		
		// 찾기
		viewIdlb.setVisible(false);
		viewNamelb.setVisible(false);
		viewHplb.setVisible(false);
		viewEmaillb.setVisible(false);
		
		updateNamelb.setVisible(false);
		updateNametf.setVisible(false);
		updatebtn.setVisible(false);
		
		updateSearchListBox.setVisible(false);
		
		searchIdlb.setVisible(false);
		searchNamelb.setVisible(false);
		searchHplb.setVisible(false);
		searchEmaillb.setVisible(false);
		
		// 수정
		/*UpdateIdlb.setVisible(false);
		UpdateNamelb.setVisible(false);
		UpdateHplb.setVisible(false);
		UpdateEmaillb.setVisible(false);
		
		UpdateIdtf.setVisible(false);
		UpdateNametf.setVisible(false);
		UpdateHptf.setVisible(false);
		UpdateEmailtf.setVisible(false);
		
		Updatebtn.setVisible(false);
		cancelbtn.setVisible(false);
		UpdateSearchListBox.setVisible(false);*/
		
		// 삭제
		
	}
	
}
