package d260127;

public class PhonebookMain {

	public static void main(String[] args) {
		new PhonebookFrame();
		//new PhonebookFrame();
	}

}
