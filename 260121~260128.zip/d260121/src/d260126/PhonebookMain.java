package d260126;

import java.io.IOException;

public class PhonebookMain {

	public static void main(String[] args) throws IOException {
		new PhonebookProgram();

	}

}
